# 32-bit-matrix-accelerator
32 Bit Accelerator Designs and Toolchain for more efficient MAC operations (Multiply and Accumulate) - Part of ITC Summer Course
